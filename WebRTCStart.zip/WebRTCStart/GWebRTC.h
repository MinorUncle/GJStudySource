//
//  GWebRTC.h
//  GWebRTC
//
//  Created by melot on 2018/4/26.
//

#import <Foundation/Foundation.h>

@interface GWebRTC : NSObject

@end
